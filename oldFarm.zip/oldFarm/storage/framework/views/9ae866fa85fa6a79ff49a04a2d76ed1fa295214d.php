<div class="logo-wrapper">
    <img src="<?php echo e(url('/images/logo_old_farm.min.png')); ?>" alt="<?php echo e(config('app.name', 'OldFarm')); ?>" class="img-fluid">
</div>
<?php /**PATH C:\xampp\htdocs\oldFarm\resources\views/components/application-logo.blade.php ENDPATH**/ ?>