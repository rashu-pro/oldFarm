<div class="logo-wrapper">
    <img src="{{ url('/images/logo_old_farm.min.png') }}" alt="{{ config('app.name', 'OldFarm') }}" class="img-fluid">
</div>
